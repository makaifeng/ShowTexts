package com.mkf_test.showtexts.ParseHttp;

import com.mkf_test.showtexts.entity.ParseHttpData;

/**
 * Created by mkf on 2017/4/11.
 */

public interface ParseHttpListener {
    void  ParseHttpSuccess(ParseHttpData data);
}
