package com.mkf_test.showtexts;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mkf_test.showtexts.db.GreenDaoManager;
import com.mkf_test.showtexts.db.table.SearchColumnTable;
import com.mkf_test.showtexts.ui.AddTagActivity;
import com.mkf_test.showtexts.ui.ShowTextActivity2;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

public class MainActivity extends BaseActivity {
    @BindView(R.id.editText)
    EditText edittext;
    @BindView(R.id.button2)
    Button showLastUrl;
    @BindView(R.id.button5)
    Button showLastUrl2;
    private String lastUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        String url="http://m.6mao.com/wapbook/4025_9559214.html";
//        String url="http://m.greattone.net/app/music.php?classid=13&id=666";
        String url = "";
        edittext.setText(url);
        if (!TextUtils.isEmpty(lastUrl)) {
            showLastUrl.setVisibility(View.VISIBLE);
            showLastUrl2.setVisibility(View.VISIBLE);
        }
//        setSupportActionBar(toolbar);
    }

    @Override
    public int getLayoutResId() {
        return R.layout.activity_main;
    }


    public void toWeb(View v) {
        String url = edittext.getText().toString().trim();
        if (TextUtils.isEmpty(url)) return;
        startActivityForResult(new Intent(this, WebActivity.class).putExtra("url", url), 1);


    }

    public void tomyview(View v) {
        String url = edittext.getText().toString().trim();
        if (TextUtils.isEmpty(url)) return;
        startActivityForResult(new Intent(this, ShowTextActivity.class).putExtra("url", url), 1);
    }

    public void showLastUrl(View v) {
        startActivityForResult(new Intent(this, WebActivity.class).putExtra("url", lastUrl), 1);

    }

    public void showLastUrl2(View v) {
        startActivityForResult(new Intent(this, ShowTextActivity.class).putExtra("url", lastUrl), 1);
    }

    public void viewBookMarks(View v) {
        startActivityForResult(new Intent(this, ListActivity.class), 2);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.test) {//测试页面
            String url = edittext.getText().toString().trim();
            if (!TextUtils.isEmpty(url)) {
                startActivityForResult(new Intent(this, ShowTextActivity2.class).putExtra("url", url), 3);
//            startActivityForResult(new Intent(this,Test.class),3);
            }
            return true;

        } else if (id == R.id.addtag) {//添加标签
            String url = edittext.getText().toString().trim();
            startActivity(new Intent(this, AddTagActivity.class).putExtra("url", url));
//            startActivityForResult(new Intent(this,Test.class),3);
            return true;

        }


        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        showLastUrlBtn();

    }

    private void showLastUrlBtn() {
        lastUrl = getSharedPreferences(getPackageName(), MODE_PRIVATE).getString("url", "");
        if (!TextUtils.isEmpty(lastUrl)) {
            showLastUrl.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            showLastUrlBtn();
        } else if (requestCode == 2 && resultCode == RESULT_OK) {
            String url = data.getStringExtra("url");
            startActivityForResult(new Intent(this, WebActivity.class).putExtra("url", url), 1);
        }
    }
}
