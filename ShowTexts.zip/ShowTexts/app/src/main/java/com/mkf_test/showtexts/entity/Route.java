package com.mkf_test.showtexts.entity;

/**
 * Created by Administrator on 2017/4/11.
 */

public class Route {
    String url;
    String name;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
